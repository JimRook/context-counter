# Context Token Counter

A visual counter to track remaining context tokens and prevent hallucinations.

## Installation

1. Open SillyTavern
2. Extensions → Install Extension
3. Paste GitHub URL
4. Refresh page

## Testing

Look for "Context Token Counter" in Extensions settings (right panel).